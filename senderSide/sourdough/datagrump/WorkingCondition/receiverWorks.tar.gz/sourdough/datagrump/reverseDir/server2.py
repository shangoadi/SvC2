import socket
import Queue
import threading	
import select

BUFFER_SIZE = 500000
PKT_SERIALNUM_MAX = 999999
# Set up a UDP server
UDPSock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

# Listen on port 21567
# (to all IP addresses on this system)
listen_addr = ("",21567)
UDPSock.bind(listen_addr)

bufferList1 = []
bufferList2 = []

packetCount = 0
def writeToTargetFile(q,BufferListLocal):
	global packetCount
	global BUFFER_SIZE
	global PKT_SERIALNUM_MAX
	
	file = open("newfile.txt", "w")
	#select.select([file],[],[])
	tempLocalList = []	

	outOfOrder = 0

	for dt in BufferListLocal:
		index,data = int(dt[0:6]),dt[6:]
		if index > packetCount:
			tempLocalList.insert( index, data)
		else:
			outOfOrder=outOfOrder+1

	for item in tempLocalList:
		file.write("%s" % item)


	
	packetCount = packetCount + BUFFER_SIZE
	if packetCount > PKT_SERIALNUM_MAX:
		packetCount = 0

	
	print outOfOrder
	exit(1)



q = Queue.Queue()

iterationCounter = 0

while True:

        data,addr = UDPSock.recvfrom(1824)
	bufferList1.append( data )
	iterationCounter = iterationCounter + 1
	#print iterationCounter
	if len(bufferList1) > BUFFER_SIZE or iterationCounter == 318073:
		bufferList2=bufferList1
		t = threading.Thread(target=writeToTargetFile, args = (q, bufferList2))
		t.start()
		print "start writing"
		bufferList1=[]

