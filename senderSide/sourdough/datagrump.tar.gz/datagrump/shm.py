import sysv_ipc
import time

# Create shared memory object
memory = sysv_ipc.SharedMemory(123456)
#memory.write("omshivam")
count = 20000
# Read value from shared memory
memory.write(str(count))
# memory.write("omkaranadan")
message = ""
#for num in range(1,1424):
#	message = message + 'y'
while True:
	time.sleep(0.005)
	memory_value = memory.read()
        print memory_value
	if memory_value[:1] == 'x':
#		memory.write(message)
		count = count + 1
		memory.write(str(count))
# Find the 'end' of the string and strip
# i = memory_value.find('\0')
# if i != -1:
    # memory_value = memory_value[:i]

